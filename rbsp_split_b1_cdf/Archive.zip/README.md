# rbsp_split_b1_cdf
Python code written by Josh Lynch to split VB1 and MSCB1 RBSP burst files. 
