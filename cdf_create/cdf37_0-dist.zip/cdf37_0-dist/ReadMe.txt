1) Please read HOWTO.run-Java-tools if you want to invoke one of the 
   Java version of the CDF tools.

2) Please read HOWTO.run-command-line-tools if you want to invoke one of 
   the command-line version of the CDF tools.

3) Please read HOWTO.run-cdf-xml-tools if you want to invoke the 
   CDF-to-CDFML or CDFML-to-CDF utility. 
